README For Rhino/Shiny App Comparison

--- Overview ---
This application and framework is designed to help guide those new to Rhino and Shiny decipher 
what changes will need to be made to convert or replicate one webapp style to another. The fortunate
thing is that Rhino is built on top of shiny, so most changes are minor. These changes come down to:

1.) Namespace and Module ID's: This allows for subcomponents of the R webapp to be more easily 
modularized and kept track of, a feature specific to Rhino apps, but not in Shiny.
2.) Orchestration File (Main.R): This coordinates the components of all Rhino app modules and funnels
all the separate pieces into one app (not required by Shiny). In this example, it may seem like 
excessive overhead, but when applications become more mature and complex, it serves a useful role.
3.) Initialization: The process of starting a Rhino app vs a Shiny app is notably different. As long
as a UI and Server function are defined or loaded into the script, the app can be kickstarted via 
"shinyApp(ui, server)". A Rhino app will coordinate across a larger pool of files, primarily 
referencing the Main.R file, which should combine components from all the other modules required
to build the app. The command to kickstart a Rhino app is simply "rhino::app()". In this example, 
all of the initialization with be done in the app.R file, however Shiny apps can have their UI, 
Server, and initialization pieces kept within the same script if the developer desires.

--- Main App Components ---
Below are some descriptions of what each file/script is used for:

* framework.txt: This text file holds the name of the app framework that the user wants to have rendered 
once they decide to run it. It will simply contain "Rhino" or "Shiny" (without quotations of course).
* chart_ui.R: This file holds all the key components for both the Shiny and Rhino apps with 
respect to user interface. It reads the framework.txt file to see whether the user wants to render
a "Rhino" or "Shiny" app, then uses if-else logic to define the UI under Rhino or Shiny logic given 
the user's preference.
* chart_server.R: This file holds all the key components for both the Shiny and Rhino apps with 
respect to the backend/server. It reads the framework.txt file to see whether the user wants to render
a "Rhino" or "Shiny" app, then uses if-else logic to define the UI under Rhino or Shiny logic given 
the user's preference.
* main.R: As mentioned previously, this is the orchestration file only required for a Rhino application 
which connects rhino modules together into one coherent application. 
* app.R: This script is used to initialize the Rhino or Shiny application, depending on user preferences 
defined in the framework.txt file.

--- Requirements ---
Note, if running in a DSS code studio, set the code environment to "shiny-general-r43" which should already include all relevant 
dependencies. The following libraries are required or recommended for running this application:

library(dplyr)
library(echarts4r)
library(htmlwidgets)
library(reactable)
library(rhino)
library(tidyr)
library(treesitter)
library(treesitter.r)