# Rhino / shinyApp entrypoint

# Trim whitespace and read text stored in the framework.txt file using the absolute file path
# This will tell us what kind of app to render, whether "Rhino" or "Shiny"
app = trimws(readLines('/home/dataiku/workspace/project-lib-versioned/R/simple_rhino_app/RhinoApplication/app/view/framework.txt'))

if (app == "Rhino") {
  # Kickstart Rhino App
  rhino::app()
} else {
  # Kickstart Shiny App
  library(dataiku)
  # Make sure paths specified below match your own working directory!
  dkuSourceLibR('simple_rhino_app/RhinoApplication/app/view/chart_server.R')
  dkuSourceLibR('simple_rhino_app/RhinoApplication/app/view/chart_ui.R')
  shinyApp(ui, server)
}


# Make ReadMe txt file that talks about each R/txt file (send screenshots of files to Simon!)