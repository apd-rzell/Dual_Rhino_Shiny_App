# User Interface Script

# Trim whitespace and read text stored in the framework.txt file using the absolute file path
# This will tell us what kind of app to render, whether "Rhino" or "Shiny"
app = trimws(readLines('/home/dataiku/workspace/project-lib-versioned/R/simple_rhino_app/RhinoApplication/app/view/framework.txt'))

# Import libraries and library subcomponents
box::use(
    reactable,
    shiny[h3, NS, fluidPage, textInput, textOutput],
)

# Define User Interface Depending on App Choice
ui <- if (app == "Rhino") { 
  # Rhino App UI
  function(id) {
  ns <- NS(id)
  fluidPage(
            id = id,
            textInput(ns("name_txt"),"Table name?"),            
            h3(textOutput(ns("tbl_name"))),
            reactable$reactableOutput(ns("table_data"))
  )}
  } else {
    # Shiny App UI
    fluidPage(
      textInput("name_txt", "Table name?"),            
      h3(textOutput("tbl_name")),
      reactable::reactableOutput("table_data")
    )
  }
  
