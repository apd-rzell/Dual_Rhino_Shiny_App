# Rhino App Orchestration File 
# Only necessary for the Rhino App

# Trim whitespace and read text stored in the framework.txt file using the absolute file path
# This will tell us what kind of app to render, whether "Rhino" or "Shiny"
app = trimws(readLines('/home/dataiku/workspace/project-lib-versioned/R/simple_rhino_app/RhinoApplication/app/view/framework.txt'))

# Import library subcomponents
box::use(
  shiny[bootstrapPage, moduleServer, NS, shinyApp],
)
# Import functions defined in the ui and server scripts/modules
box::use(
  view/chart_ui,
  view/chart_server,  # Add new hist module
)

# Assign module functions to new variables
ui <- chart_ui$ui
server <- chart_server$server